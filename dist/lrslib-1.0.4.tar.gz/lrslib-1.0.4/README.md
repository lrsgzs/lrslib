这是LRSLIB

里面有许多好用的功能

祝你好运~

Doc   文档

'tkin.Window':'对Tk()进行优化的适合中国人的一个类',

'tools.pront':'一个一个地打印文本',

'tools.show_image':'显示图片在pygame窗口中'

'by':'关于'

'func':'帮助'
