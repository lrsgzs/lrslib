这是LRSLIB

里面有许多好用的功能

祝你好运~

Doc   文档

'tkin.Window':'仿tk窗口，用Button时，Tk()为 .win',

'tools.pront':'一个一个地打印文本',

'tools.show_image':'显示图片在pygame窗口中'

'by':'关于'

'func':'帮助'
